/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * sleep.c
 *
 * Code generation for function 'sleep'
 *
 */

/* Include files */
#include "sleep.h"
#include <stdio.h>
#include <string.h>

/* Custom Source Code */
me
  /* Type Definitions */
#include <stdio.h>

/* Function Definitions */
void sleep(const double x[28801], const double y[28801])
{
  double deep_sleep[10229];
  int x3;
  int aux;
  int i;
  double j;
  (void)y;
  memset(&deep_sleep[0], 0, 10229U * sizeof(double));
  x3 = -1;
  aux = 0;
  for (i = 0; i < 28801; i++) {
    if (!(x[i] <= 1.0)) {
      j = x[i] - x[aux];
      if (((!(j <= 0.841)) || (!(j > 0.69))) && (!(j <= 0.691)) && (j <= 1.061) &&
          (j > 0.841)) {
        x3++;
        deep_sleep[x3] = x[i];
      }

      aux++;
    }
  }

  printf("Hours in deep sleep %f \n", (deep_sleep[10228] - deep_sleep[0]) / 60.0
         / 60.0);
  fflush(stdout);
}

/* End of code generation (sleep.c) */
