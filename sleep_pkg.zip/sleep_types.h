/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * sleep_types.h
 *
 * Code generation for function 'sleep_types'
 *
 */

#ifndef SLEEP_TYPES_H
#define SLEEP_TYPES_H

/* Include files */
#include "rtwtypes.h"
#endif

/* End of code generation (sleep_types.h) */
