/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * sleep_terminate.c
 *
 * Code generation for function 'sleep_terminate'
 *
 */

/* Include files */
#include "sleep_terminate.h"
#include "sleep.h"

/* Function Definitions */
void sleep_terminate(void)
{
  /* (no terminate code required) */
}

/* End of code generation (sleep_terminate.c) */
