﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SpaceApp
{
    public partial class Profile : Form
    {

        MorfeoAppEntities context = new MorfeoAppEntities();
        public Profile()
        {
            InitializeComponent();
        }



        private void Profile_Load(object sender, EventArgs e)
        {
            string cadSQL = $"select * from Astronaut where idAstr = '{Form1.idAstron}'";

            List<Astronaut> lsAstr = context.Astronaut.SqlQuery(cadSQL).ToList();
            //We know the astronaut exits because it was verified in Form1.
            lbNa.Text = lsAstr[0].name + " " + lsAstr[0].surname;
            int edad = DateTime.Now.Year -  lsAstr[0].birth.Value.Year;
            lbAg.Text = Convert.ToString(edad);
            lbge.Text = lsAstr[0].gender;
            lbHei.Text = Convert.ToString(lsAstr[0].height);
            lbWei.Text = Convert.ToString(lsAstr[0].weight);
            lbNaci.Text = lsAstr[0].nationality;

            
        }
    }
}
