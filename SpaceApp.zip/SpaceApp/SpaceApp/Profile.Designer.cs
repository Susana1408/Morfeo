﻿namespace SpaceApp
{
    partial class Profile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbN = new System.Windows.Forms.Label();
            this.lbAge = new System.Windows.Forms.Label();
            this.lbGender = new System.Windows.Forms.Label();
            this.lbNac = new System.Windows.Forms.Label();
            this.lbHeight = new System.Windows.Forms.Label();
            this.lbWeight = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbNa = new System.Windows.Forms.Label();
            this.lbWei = new System.Windows.Forms.Label();
            this.lbNaci = new System.Windows.Forms.Label();
            this.lbge = new System.Windows.Forms.Label();
            this.lbAg = new System.Windows.Forms.Label();
            this.lbHei = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbN
            // 
            this.lbN.AutoSize = true;
            this.lbN.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbN.Location = new System.Drawing.Point(12, 9);
            this.lbN.Name = "lbN";
            this.lbN.Size = new System.Drawing.Size(107, 27);
            this.lbN.TabIndex = 0;
            this.lbN.Text = "Nombre: ";
            // 
            // lbAge
            // 
            this.lbAge.AutoSize = true;
            this.lbAge.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAge.Location = new System.Drawing.Point(24, 39);
            this.lbAge.Name = "lbAge";
            this.lbAge.Size = new System.Drawing.Size(46, 18);
            this.lbAge.TabIndex = 1;
            this.lbAge.Text = "Age: ";
            // 
            // lbGender
            // 
            this.lbGender.AutoSize = true;
            this.lbGender.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbGender.Location = new System.Drawing.Point(24, 72);
            this.lbGender.Name = "lbGender";
            this.lbGender.Size = new System.Drawing.Size(68, 18);
            this.lbGender.TabIndex = 2;
            this.lbGender.Text = "Gender:";
            // 
            // lbNac
            // 
            this.lbNac.AutoSize = true;
            this.lbNac.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNac.Location = new System.Drawing.Point(24, 103);
            this.lbNac.Name = "lbNac";
            this.lbNac.Size = new System.Drawing.Size(96, 18);
            this.lbNac.TabIndex = 3;
            this.lbNac.Text = "Nacionality:";
            // 
            // lbHeight
            // 
            this.lbHeight.AutoSize = true;
            this.lbHeight.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbHeight.Location = new System.Drawing.Point(232, 39);
            this.lbHeight.Name = "lbHeight";
            this.lbHeight.Size = new System.Drawing.Size(61, 18);
            this.lbHeight.TabIndex = 4;
            this.lbHeight.Text = "Height:";
            // 
            // lbWeight
            // 
            this.lbWeight.AutoSize = true;
            this.lbWeight.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbWeight.Location = new System.Drawing.Point(232, 72);
            this.lbWeight.Name = "lbWeight";
            this.lbWeight.Size = new System.Drawing.Size(65, 18);
            this.lbWeight.TabIndex = 5;
            this.lbWeight.Text = "Weight:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(232, 105);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 17);
            this.label2.TabIndex = 6;
            // 
            // lbNa
            // 
            this.lbNa.AutoSize = true;
            this.lbNa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNa.Location = new System.Drawing.Point(115, 11);
            this.lbNa.Name = "lbNa";
            this.lbNa.Size = new System.Drawing.Size(64, 25);
            this.lbNa.TabIndex = 7;
            this.lbNa.Text = "label1";
            // 
            // lbWei
            // 
            this.lbWei.AutoSize = true;
            this.lbWei.Location = new System.Drawing.Point(303, 74);
            this.lbWei.Name = "lbWei";
            this.lbWei.Size = new System.Drawing.Size(46, 17);
            this.lbWei.TabIndex = 8;
            this.lbWei.Text = "label1";
            // 
            // lbNaci
            // 
            this.lbNaci.AutoSize = true;
            this.lbNaci.Location = new System.Drawing.Point(133, 103);
            this.lbNaci.Name = "lbNaci";
            this.lbNaci.Size = new System.Drawing.Size(46, 17);
            this.lbNaci.TabIndex = 9;
            this.lbNaci.Text = "label3";
            // 
            // lbge
            // 
            this.lbge.AutoSize = true;
            this.lbge.Location = new System.Drawing.Point(117, 72);
            this.lbge.Name = "lbge";
            this.lbge.Size = new System.Drawing.Size(46, 17);
            this.lbge.TabIndex = 10;
            this.lbge.Text = "label4";
            // 
            // lbAg
            // 
            this.lbAg.AutoSize = true;
            this.lbAg.Location = new System.Drawing.Point(92, 40);
            this.lbAg.Name = "lbAg";
            this.lbAg.Size = new System.Drawing.Size(46, 17);
            this.lbAg.TabIndex = 11;
            this.lbAg.Text = "label5";
            // 
            // lbHei
            // 
            this.lbHei.AutoSize = true;
            this.lbHei.Location = new System.Drawing.Point(303, 40);
            this.lbHei.Name = "lbHei";
            this.lbHei.Size = new System.Drawing.Size(46, 17);
            this.lbHei.TabIndex = 12;
            this.lbHei.Text = "label1";
            // 
            // Profile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(543, 259);
            this.Controls.Add(this.lbHei);
            this.Controls.Add(this.lbAg);
            this.Controls.Add(this.lbge);
            this.Controls.Add(this.lbNaci);
            this.Controls.Add(this.lbWei);
            this.Controls.Add(this.lbNa);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbWeight);
            this.Controls.Add(this.lbHeight);
            this.Controls.Add(this.lbNac);
            this.Controls.Add(this.lbGender);
            this.Controls.Add(this.lbAge);
            this.Controls.Add(this.lbN);
            this.Name = "Profile";
            this.Text = "Profile";
            this.Load += new System.EventHandler(this.Profile_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbN;
        private System.Windows.Forms.Label lbAge;
        private System.Windows.Forms.Label lbGender;
        private System.Windows.Forms.Label lbNac;
        private System.Windows.Forms.Label lbHeight;
        private System.Windows.Forms.Label lbWeight;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbNa;
        private System.Windows.Forms.Label lbWei;
        private System.Windows.Forms.Label lbNaci;
        private System.Windows.Forms.Label lbge;
        private System.Windows.Forms.Label lbAg;
        private System.Windows.Forms.Label lbHei;
    }
}