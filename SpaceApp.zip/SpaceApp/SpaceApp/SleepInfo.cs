﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SpaceApp
{
    public partial class SleepInfo : Form
    {
        MorfeoAppEntities context = new MorfeoAppEntities();
        public SleepInfo()
        {
            InitializeComponent();

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void SleepInfo_Load(object sender, EventArgs e)
        {
            this.lbTi.AutoSize = false;
            this.lbTi.Height = 25;

            lbBoolean.Text = "True"; //This information will be provided by the electrocardiogram
        }

        private void btAdd_Click(object sender, EventArgs e)
        {
            MessageBox.Show(dtNight.Value.ToShortDateString());
            MessageBox.Show(dtNight.Text);

            string cadSQL;
            cadSQL = $"select * from Trip t, Astronauta a, where a.idAstr = 3" ;

            List<Trip> lsTrip = context.Trip.SqlQuery(cadSQL).ToList();

            //Verifing that the information is correct
            if (lsTrip.Count != 0)
            {

                MainWindow w = new MainWindow();
                w.Show();


            }
            else
                MessageBox.Show("Incorrect information.");

        }
    }
}
